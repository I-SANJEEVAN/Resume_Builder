export { default as Intro } from './Intro/Intro';
export { default as TechnicalExpertise } from './TechnicalExpertise/TechnicalExpertise';
export { default as UnratedCapsules } from './UnratedCapsules/UnratedCapsules';
export { default as Education } from './Education/Education';
export { default as Social } from './Social/Social';
