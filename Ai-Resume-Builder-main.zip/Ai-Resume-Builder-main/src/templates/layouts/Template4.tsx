import React from 'react';
// import shallow from 'zustand/shallow';
// import {
//   useIntro,
//   useWork,
//   useSkills,
//   useAchievements,
//   useEducation,
// } from 'stores/data.store';

export function Template4() {
  // Uncomment below lines to access data

  // const intro = useIntro((state: any) => state.intro);
  // const education = useEducation((state: any) => state.education);
  // const experience = useWork((state: any) => state);
  // const [keyProjects, certificates] = useAchievements(
  //   (state: any) => [state.keyProjects, state.certificates],
  //   shallow
  // );
  // const [languages, frameworks, libraries, databases, technologies, practices, tools] = useSkills(
  //   (state: any) => [
  //     state.languages,
  //     state.frameworks,
  //     state.libraries,
  //     state.databases,
  //     state.technologies,
  //     state.practices,
  //     state.tools,
  //   ],
  //   shallow
  // );

  return <h1>Template4: Sandeep Balachandran</h1>;
}
